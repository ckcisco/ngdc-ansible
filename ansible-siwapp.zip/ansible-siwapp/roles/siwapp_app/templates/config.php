<?php
$sw_installed = true;
$options['sf_web_dir'] = dirname(__FILE__);
$options['sf_root_dir'] = realpath($options['sf_web_dir'].DIRECTORY_SEPARATOR.'..');
